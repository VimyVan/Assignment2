package com.teacher;
import java.io.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
public class Teacher2014302580130 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try
		{
			Document doc = Jsoup.connect("http://staff.whu.edu.cn/show.jsp?lang=cn&n=Ai Xin Ping").get();
			Elements links = doc.select("p:matches(��|��)");
			Elements links1 = doc.select("h3");
			Elements masthead = doc.select("div.szll_wz_bt");
			
			File f=new File("out.txt");
		    f.createNewFile();
		    FileOutputStream fileOutputStream = new FileOutputStream(f);
		    PrintStream printStream = new PrintStream(fileOutputStream);
		    System.setOut(printStream);
		    
		    String string = links.eq(0).text();
		    Pattern p=Pattern.compile("\\d+"); 
			Matcher m=p.matcher(string); 
			while(m.find()) { 
			     System.out.println(m.group()); 
			} 
			
			Pattern p1=Pattern.compile("\\w+@{1}\\w+\\.\\w+\\.\\w+"); 
			Matcher m1=p1.matcher(string); 
			while(m1.find()) { 
			     System.out.println(m1.group()); 
			} 
			
		    for (Element link1 : links1) {
				String linkText1 = link1.text();
				System.out.println(linkText1);
		    }
		    
		    for(int i=0;i<4;i++)
		    {
			   String linkText = links.eq(i).text();
			   System.out.println(linkText);
			   String mastheadsText = masthead.eq(i).text();
		       System.out.println(mastheadsText);
		    }
		    String linkText = links.eq(4).text();
		    System.out.println(linkText);
		}
		catch(Exception ex){
			ex.printStackTrace();
			}
	}
}
